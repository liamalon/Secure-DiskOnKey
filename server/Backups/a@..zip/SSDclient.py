
from glob import glob
import os
import threading
from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.properties import ObjectProperty
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.core.text import LabelBase    
import socket



import sys
sys.path.insert(3, 'Asset')
from encrypt import encrypt,decrypt,cleanup
from zip import zip_all,unzip_all
from tcp_by_size import recv_by_size,send_with_size

###  Register font pack for labels  ###
LabelBase.register(name= "txt_font",
    fn_regular= "Asset\\orange juice 2.0.ttf")

SERVER_IP = "127.0.0.1"

SERVER_PORT = 4444

sock = socket.socket()

t= threading.Thread()

class CreateAccountWindow(Screen):
    """
        --> Create new account page <--
            --> For new users <--
    """
    namee = ObjectProperty(None)
    email = ObjectProperty(None)
    password = ObjectProperty(None)

    def submit(self):
        global t
        if self.namee.text != "" and self.email.text != "" and self.email.text.count("@") == 1 and self.email.text.count(".") > 0:
            if self.password != "":

                len_data = str(len(self.email.text.encode() +b"~"+ self.password.text.encode() +b"~"+ self.namee.text.encode()+b"###")).zfill(16)

                print(len_data)

                sock.send(b"SUBM~"+len_data.encode()+b"~"+self.email.text.encode() +b"~"+ self.password.text.encode() +b"~"+ self.namee.text.encode()+b"###")

                len_data = str(len(self.email.text.encode()+b"###")).zfill(16)

                sock.send(b"GETK~"+len_data.encode()+b"~"+self.email.text.encode()+b"###")

                key = sock.recv(1024)

                key = key.decode()

                t= threading.Thread(target=encrypt, args=(key,))

                t.start()

                ziping()    

                self.reset()

                sm.current = "login"

                """
                if "f" == t.join():
                    done_zip()
                """

            else:
                invalidForm()
        else:
            invalidForm()

    def login(self):
        self.reset()
        sm.current = "login"

    def reset(self):
        self.email.text = ""
        self.password.text = ""
        self.namee.text = ""


class LoginWindow(Screen):
    email = ObjectProperty(None)
    password = ObjectProperty(None)

    def loginBtn(self):
        global t
        """
        --> If btn was clicked checks if user exits withe server <--
        """
        if t.is_alive() == False:
            len_data = str(len(self.email.text.encode() + b"~" +  self.password.text.encode()+b"###")).zfill(16)

            sock.send(b"CLOG~"+len_data.encode()+b"~"+self.email.text.encode() + b"~" +  self.password.text.encode()+b"###")

            valid = sock.recv(1024)
            if valid ==b"True":
                MainWindow.current = self.email.text

                len_data = str(len(self.email.text.encode()+b"###")).zfill(16)

                sock.send(b"GETK~"+len_data.encode()+b"~"+self.email.text.encode()+b"###")

                key = sock.recv(1024)

                key = key.decode()

                t= threading.Thread(target=decrypt, args=(key,))

                t.start()

                unziping()


                self.reset()
                sm.current = "main"
            else:
                invalidLogin()
        else:
            zip_not_done()

    def createBtn(self):
        self.reset()
        sm.current = "create"

    def reset(self):
        self.email.text = ""
        self.password.text = ""

class MainWindow(Screen):
    n = ObjectProperty(None)
    created = ObjectProperty(None)
    email = ObjectProperty(None)
    current = ""

    def logOut(self):
        len_data = str(len(self.current+"###")).zfill(16)

        sock.send(b"GETK~"+ len_data.encode() + b"~" + self.current.encode()+b"###")
        print("logging out")

        key = sock.recv(1024)

        key = key.decode()

        t= threading.Thread(target=encrypt, args=(key,))

        t.start()

        ziping()

        sm.current = "login"

    def create_backup(self):

        print("Creating backup")

        CURRENT_DISK =  os.getcwd().split("\\")[0] +"\\"

        zip_all(CURRENT_DISK,"BACKUP")

        with open(CURRENT_DISK+"BACKUP.zip" , "rb") as zip_to_read:
            file_data = zip_to_read.read()
        
        file_data = file_data.decode("IBM437")

        len_data = str(len(b"~"+self.current.encode() + file_data.encode("IBM437") + b"###")).zfill(16)

        sock.send(b"CRTB~" + len_data.encode() + b"~"+self.current.encode()+b"~" + file_data.encode("IBM437") + b"###")

        cleanup("BACKUP.zip")

    def create_backup_zip(self):

        t= threading.Thread(target=self.create_backup, args=())

        t.start()

        creating_backup()


    
    def get_backup(self):

        print("Getting backup")

        len_data = str(len(self.current.encode()+b"###")).zfill(16)

        sock.send(b"GETB~"+ len_data.encode() + b"~" + self.current.encode()+b"###")

        data  = recv_backup()

        with open(f"Backup.zip","wb") as write_zip:
                write_zip.write(data.encode("IBM437"))

        CURRENT_DISK =  os.getcwd().split("\\")[0] +"\\"

        #unzip_all(CURRENT_DISK,"Backup.zip")

        #cleanup("Backup.zip")

    def get_backup_zip(self):

        t= threading.Thread(target=self.get_backup, args=())

        t.start()

        getting_backup()




    def changePassword(self):
        sm.current = "cpass"
        

    def on_enter(self, *args):

        len_data = str(len(self.current.encode()+b"###")).zfill(16)

        sock.send(b"GETU~"+len_data.encode()+b"~"+self.current.encode()+b"###")

        encoded_user_info = sock.recv(1024)

        decoded_user_info = encoded_user_info.decode()

        splited_user_info = decoded_user_info.split("~")

        password = splited_user_info[0]

        name = splited_user_info[1]

        created = splited_user_info[2]

        self.n.text = "Account Name: " + name

        self.email.text = "Email: " + self.current

        self.created.text = "Created On: " + created

def recv_backup():
    code = sock.recv(5)
    code = code.decode()[:4]
    str_data = recv_by_size(sock)
    str_data = str_data.decode("IBM437")
    str_data = str_data.split("###")[0]
    name = str_data.split("~")[0]
    backup_data = str_data.split(name+"~")[1]
    return backup_data


class ChangePassword(Screen):
    old_password = ObjectProperty(None)
    password = ObjectProperty(None)

    def changepassbtn(self):

        

        len_data = str(len(MainWindow.current.encode()+b"~"+self.old_password.text.encode()+b"~"+self.password.text.encode()+b"###")).zfill(16)

        print(len_data)

        print(MainWindow.current)

        sock.send(b"CHNP~"+len_data.encode()+b"~"+MainWindow.current.encode()+b"~"+self.old_password.text.encode()+b"~"+self.password.text.encode()+b"###")
        
        print("sent")

        Is_oldpass_ok = sock.recv(1024)

        if Is_oldpass_ok == b"bad password":
            badPassword()

        else:
            

            self.reset()

            sm.current = "main"
        
    def reset(self):
        self.old_password.text = ""
        self.password.text = ""

    def back_to_main(self):
        self.reset()
        sm.current = "main"

class WindowManager(ScreenManager):
    pass

def invalidLogin():
    pop = Popup(title='Invalid Login',
                  content=Label(text='Invalid username or password.'),
                  size_hint=(None, None), size=(400, 400))
    pop.open()
    
def badPassword():
    pop = Popup(title='Invalid Password',
                  content=Label(text='Invalid password. Please try again'),
                  size_hint=(None, None), size=(400, 400))
    pop.open()

def ziping():
    pop = Popup(title='Files are zipping',
                  content=Label(text='The files are zipping it might take a while...'),
                  size_hint=(None, None), size=(400, 400))
    pop.open()

def done_zip():
    pop = Popup(title='Files are finished zipping',
                  content=Label(text='The files finished zipping \n You can log in now'),
                  size_hint=(None, None), size=(400, 400))
    pop.open()

def unziping():
    pop = Popup(title='Files are unziping',
                  content=Label(text='The files are unziping it might take a while...'),
                  size_hint=(None, None), size=(400, 400))
    pop.open()

def done_unzip():
    pop = Popup(title='Files are finished unzipping',
                  content=Label(text='The files finished unzipping \n You can use them now'),
                  size_hint=(None, None), size=(400, 400))
    pop.open()

def invalidForm():
    pop = Popup(title='Invalid Form',
                  content=Label(text='Please fill in all inputs with valid information.'),
                  size_hint=(None, None), size=(400, 400))

    pop.open()

def zip_not_done():
    pop = Popup(title='Files are not finished zipping',
                  content=Label(text='The files are not finished zipping \n Please wait'),
                  size_hint=(None, None), size=(400, 400))
    pop.open()

def creating_backup():
    pop = Popup(title='Creating backup',
                  content=Label(text='Backup is being created '),
                  size_hint=(None, None), size=(400, 400))
    pop.open()

def getting_backup():
    pop = Popup(title='Getting backup',
                  content=Label(text='Backup is being restored '),
                  size_hint=(None, None), size=(400, 400))
    pop.open()

kv = Builder.load_file("Asset\\my.kv")

sm = WindowManager()



screens = [LoginWindow(name="login"), CreateAccountWindow(name="create"),MainWindow(name="main"),ChangePassword(name="cpass")]
for screen in screens:
    sm.add_widget(screen)

sm.current = "login"

class MyMainApp(App):
    def build(self):
        return sm

def connect_to_server():
    global sock
    try:
        sock.connect((SERVER_IP, SERVER_PORT))
        print(f'Connect succeeded {SERVER_IP}:{SERVER_PORT}')
        connected = True
    except:
        print(f'Error while trying to connect.  Check ip or port -- {SERVER_IP}:{SERVER_PORT}')

if __name__ == "__main__":
    connect_to_server()
    MyMainApp().run()

     