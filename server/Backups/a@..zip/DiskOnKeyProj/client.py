
from tkinter import Wm
from traceback import print_tb
from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.properties import ObjectProperty
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.core.text import LabelBase
import socket
from database import DataBase
from encrypt import encrypt,decrypt

###  Register font pack for labels  ###
LabelBase.register(name= "txt_font",
    fn_regular= "orange juice 2.0.ttf")

SERVER_IP = "127.0.0.1"

SERVER_PORT = 4444

sock = socket.socket()


class CreateAccountWindow(Screen):
    """
        --> Create new account page <--
            --> For new users <--
    """
    namee = ObjectProperty(None)
    email = ObjectProperty(None)
    password = ObjectProperty(None)

    def submit(self):
        if self.namee.text != "" and self.email.text != "" and self.email.text.count("@") == 1 and self.email.text.count(".") > 0:
            if self.password != "":
                sock.send(b"SUBM~"+self.email.text.encode() +b"~"+ self.password.text.encode() +b"~"+ self.namee.text.encode())
                
                sock.send(b"GETK~"+self.email.text.encode())
                encrypt(sock.recv(1024))

                self.reset()

                sm.current = "login"
            else:
                invalidForm()
        else:
            invalidForm()

    def login(self):
        self.reset()
        sm.current = "login"

    def reset(self):
        self.email.text = ""
        self.password.text = ""
        self.namee.text = ""


class LoginWindow(Screen):
    email = ObjectProperty(None)
    password = ObjectProperty(None)

    def loginBtn(self):
        """
        --> If btn was clicked checks if user exits withe server <--
        """
        sock.send(b"CLOG~"+self.email.text.encode() + b"~" +  self.password.text.encode())
        valid = sock.recv(1024)
        if valid ==b"True":
            MainWindow.current = self.email.text
            sock.send(b"GETK~"+self.email.text.encode())
            decrypt(sock.recv(1024))
            self.reset()
            sm.current = "main"
        else:
            invalidLogin()

    def createBtn(self):
        self.reset()
        sm.current = "create"

    def reset(self):
        self.email.text = ""
        self.password.text = ""


class MainWindow(Screen):
    n = ObjectProperty(None)
    created = ObjectProperty(None)
    email = ObjectProperty(None)
    current = ""

    def logOut(self):
        sock.send(b"GETK~"+self.current.encode())
        print("log out")
        encrypt(sock.recv(1024))
        sm.current = "login"

    def on_enter(self, *args):

        sock.send(b"GETU~"+self.current.encode())

        encoded_user_info = sock.recv(1024)

        decoded_user_info = encoded_user_info.decode()

        splited_user_info = decoded_user_info.split("~")

        password = splited_user_info[0]

        name = splited_user_info[1]

        created = splited_user_info[2]
        
        self.n.text = "Account Name: " + name

        self.email.text = "Email: " + self.current

        self.created.text = "Created On: " + created


class WindowManager(ScreenManager):
    pass


def invalidLogin():
    pop = Popup(title='Invalid Login',
                  content=Label(text='Invalid username or password.'),
                  size_hint=(None, None), size=(400, 400))
    pop.open()


def invalidForm():
    pop = Popup(title='Invalid Form',
                  content=Label(text='Please fill in all inputs with valid information.'),
                  size_hint=(None, None), size=(400, 400))

    pop.open()


kv = Builder.load_file("my.kv")

sm = WindowManager()

screens = [LoginWindow(name="login"), CreateAccountWindow(name="create"),MainWindow(name="main")]
for screen in screens:
    sm.add_widget(screen)

sm.current = "login"

class MyMainApp(App):
    def build(self):
        return sm
    
def connect_to_server():
    global sock
    try:
        sock.connect((SERVER_IP, SERVER_PORT))
        print(f'Connect succeeded {SERVER_IP}:{SERVER_PORT}')
        connected = True
    except:
        print(f'Error while trying to connect.  Check ip or port -- {SERVER_IP}:{SERVER_PORT}')

if __name__ == "__main__":
    connect_to_server()
    MyMainApp().run()

     