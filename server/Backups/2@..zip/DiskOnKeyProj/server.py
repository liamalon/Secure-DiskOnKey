from database import DataBase
import socket
import threading
import encrypt

db = DataBase("users.txt")

ROOMS_PORT = 4444

"""
Check if user in database
"""

def check_login(name_and_password,sock):
        print(name_and_password)
        name = name_and_password[1]
        password = name_and_password[2]
        if db.validate(name, password):
                sock.send(b"True")
        else:
                sock.send(b"False")
        
def submit(new_user,sock):
        """
        --> Adds user to DataBase <--
        """        
        email = new_user[1]

        password = new_user[2]

        name = new_user[3]

        key = create_key()
        
        db.add_user(email, password, name, key.decode())


        

def get_user(user,sock):
        print(user)
        password, name, created,key = db.get_user(user[1])
        print(password.encode() +b"~" +name.encode()  +b"~" +created.encode())
        sock.send(password.encode() +b"~" +name.encode()  +b"~" +created.encode())

def create_key():
        return encrypt.create_key()

def get_user_key(user,sock):
        print("sent key")
        print(db.get_key(user[1]))
        sock.send(db.get_key(user[1]).encode())

def handle_clients(sock):
        while True:
                bytes_data = sock.recv(1024)
                str_data = bytes_data.decode()
                print(str_data)
                splited_str_data = str_data.split("~")
                code = splited_str_data[0]
                
                if code == "CLOG":
                        check_login(splited_str_data,sock)
                elif code == "SUBM":
                        submit(splited_str_data,sock)
                elif code == "GETU":
                        get_user(splited_str_data,sock)
                elif code == "GETK":
                        get_user_key(splited_str_data,sock)


def wait_for_clients():
        """
        connetcting with socket to client
        main server loop
        1. that accept tcp connection
        2. create thread for each connected new client
        3. wait for all threads
        4. every X clients limit will exit
        """
        threads = []
        srv_sock = socket.socket()
        srv_sock.bind(('0.0.0.0', ROOMS_PORT))
        srv_sock.listen(20)
        srv_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        i = 1
        while True:
                print('Main thread: before accepting ...')
                cli_sock , addr = srv_sock.accept()
                print(f"Client connected || ip --> {addr} ")
                t = threading.Thread(target = handle_clients, args=(cli_sock,))
                t.start()
                i+=1
                threads.append(t)
                if i > 100000000:     # for tests change it to 4
                        print('Main thread: going down for maintenance')
                        break

        all_to_die = True
        print('Main thread: waiting to all clints to die')
        for t in threads:
                t.join()
        srv_sock.close()
        print( 'Bye ..')


if __name__ == "__main__":
    wait_for_clients()