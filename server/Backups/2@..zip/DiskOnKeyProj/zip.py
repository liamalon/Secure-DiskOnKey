__author__ = "Liam Alon"
__date__ = "25/02/2022"
import shutil
import os



def zip_all(path):
   """
   --> Zip all of the files to one file <-- 
   """

   """
   to do everything
   shutil.make_archive("EVERYTHING", 'zip', CURRENT_DISK)
   """
   
   shutil.make_archive("EVERYTHING", 'zip', path)
   print("zipped")

def unzip_all():
   """
   --> Unzip the file to get the original Files <-- 
   """

   """
   to do everything
   shutil.make_archive("EVERYTHING", 'zip', CURRENT_DISK)
   """
   
   shutil.unpack_archive("EVERYTHING.zip","D:\\DiskOnKeyProj\\tryme")
   print("unzipped")

if __name__ == "__main__":
   pass